"""
main.py
Entry point for the CS‑340 Animal Rescue Dashboard.

Launch with:
    python main.py
"""

import pandas as pd
from jupyter_dash import JupyterDash

from db_module import AnimalShelter
import ui_module


def launch_app(debug: bool = True):
    # Initial data fetch
    shelter = AnimalShelter()
    df_initial = pd.DataFrame.from_records(shelter.read({}))

    # Build UI
    app = JupyterDash('CS‑340 Dashboard – Faris Malik')
    app.layout = ui_module.build_layout(df_initial)
    ui_module.register_callbacks(app, df_initial)

    app.run_server(debug=debug)


if __name__ == '__main__':
    launch_app()
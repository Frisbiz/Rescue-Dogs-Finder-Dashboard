"""
db_module.py
Handles database connection and CRUD operations for the AAC collection.

Extracted from the original monolithic notebook to improve modularity and
maintainability for Milestone Two (CS 499, Enhancement One).
"""

from pymongo import MongoClient


class AnimalShelter:
    def __init__(self):
        self.client = MongoClient("mongodb://localhost:27017")
        self.database = self.client["AAC"]
        self.collection = self.database["animals"]
        uri = f"mongodb://{user}:{password}@{host}:{port}"
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    # 'C' in CRUD (Create)
    def create(self, data: dict) -> bool:
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as exc:
                print(f"Error inserting data: {exc}")
        return False

    # 'R' in CRUD (Read)
    def read(self, query: dict | None = None) -> list[dict]:
        try:
            if query:
                return list(self.collection.find(query, {'_id': False}))
            return list(self.collection.find({}, {'_id': False}))
        except Exception as exc:
            print(f"Error reading data: {exc}")
            return []

    # 'U' in CRUD (Update)
    def update(self, query: dict, new_values: dict) -> int:
        try:
            result = self.collection.update_many(query, {'$set': new_values})
            return result.modified_count
        except Exception as exc:
            print(f"Error updating data: {exc}")
            return 0

    # 'D' in CRUD (Delete)
    def delete(self, query: dict) -> int:
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as exc:
            print(f"Error deleting data: {exc}")
            return 0
"""
ui_module.py
Builds the Dash UI layout and all callbacks.

Separated from the data layer (db_module.py) to comply with single‑responsibility
and to simplify future maintenance.
"""

import pandas as pd
import plotly.express as px
from dash import Dash, html, dcc, dash_table, Output, Input, State, no_update
import dash_leaflet as dl
from jupyter_dash import JupyterDash

from db_module import AnimalShelter

# Instantiate data layer
shelter = AnimalShelter()

def build_layout(df: pd.DataFrame) -> html.Div:
    """Returns the root Div for the dashboard."""
    return html.Div([
        html.Center(html.B(html.H1('SNHU CS‑340 Dashboard – Faris Malik'))),

        html.A(
            html.Img(src='assets/Grazioso Salvare Logo.png',
                     style={'height': '100px'}),
            href='https://www.snhu.edu',
            target='_blank'
        ),

        html.Hr(),

        dcc.RadioItems(
            id='rescue-filter',
            options=[
                {'label': 'Water Rescue', 'value': 'Water Rescue'},
                {'label': 'Mountain Rescue', 'value': 'Mountain Rescue'},
                {'label': 'Disaster Rescue', 'value': 'Disaster Rescue'},
                {'label': 'Reset', 'value': 'Reset'}
            ],
            labelStyle={'display': 'inline-block', 'marginRight': '10px'},
            style={'display': 'flex', 'flexWrap': 'wrap',
                   'justifyContent': 'flex-start'}
        ),

        html.Br(),

        dash_table.DataTable(
            id='datatable-id',
            columns=[{'name': i, 'id': i} for i in df.columns],
            data=df.to_dict('records'),
            editable=False,
            filter_action='native',
            sort_action='native',
            sort_mode='single',
            row_selectable='single',
            selected_rows=[],
            page_action='native',
            page_size=10
        ),

        html.Br(),

        html.Div([
            html.Div([dcc.Graph(id='pie-chart')],
                     style={'width': '48%', 'display': 'inline-block'}),
            html.Div([html.Div(id='map-id')],
                     style={'width': '48%', 'display': 'inline-block',
                            'paddingLeft': '20px'})
        ], style={'display': 'flex', 'justifyContent': 'space-between'}),

        html.Br(),

        # New "Reset All" button clears radio selection and table/map selections
        html.Button('Reset All', id='reset-all', n_clicks=0),

        html.Hr(),

        html.Div('Unique ID: Faris Malik', style={'marginTop': '20px'})
    ])


def register_callbacks(app: Dash, df: pd.DataFrame):
    """All callbacks bundled in a helper for clarity."""

    @app.callback(
        Output('datatable-id', 'data'),
        Input('rescue-filter', 'value')
    )
    def filter_data(rescue_type):
        if rescue_type == 'Water Rescue':
            query = {
                'breed': {'$in': ['Labrador Retriever Mix',
                                  'Chesapeake Bay Retriever',
                                  'Newfoundland']},
                'age_upon_outcome_in_weeks': {'$gte': 26, '$lte': 156},
                'sex_upon_outcome': {'$regex': 'Intact Female'}
            }
        elif rescue_type == 'Mountain Rescue':
            query = {
                'breed': {'$in': ['German Shepherd', 'Alaskan Malamute',
                                  'Old English Sheepdog', 'Siberian Husky',
                                  'Rottweiler']},
                'age_upon_outcome_in_weeks': {'$gte': 26, '$lte': 156},
                'sex_upon_outcome': {'$regex': 'Intact Male'}
            }
        elif rescue_type == 'Disaster Rescue':
            query = {
                'breed': {'$in': ['Doberman Pinscher', 'German Shepherd',
                                  'Golden Retriever', 'Bloodhound',
                                  'Rottweiler']},
                'age_upon_outcome_in_weeks': {'$gte': 20, '$lte': 300},
                'sex_upon_outcome': {'$regex': 'Intact Male'}
            }
        else:  # Reset or None
            query = {}

        filtered = shelter.read(query)
        return pd.DataFrame(filtered).to_dict('records')

    @app.callback(
        Output('pie-chart', 'figure'),
        Input('datatable-id', 'data')
    )
    def update_pie_chart(data):
        if not data:
            return {}
        df_local = pd.DataFrame(data)
        return px.pie(df_local, names='breed',
                      title='Breed Distribution')

    @app.callback(
        Output('map-id', 'children'),
        Input('datatable-id', 'derived_virtual_data'),
        Input('datatable-id', 'derived_virtual_selected_rows')
    )
    def update_map(view_data, selected):
        if not view_data:
            return [html.P('No data available.')]

        dff = pd.DataFrame(view_data)
        row = 0 if not selected else selected[0]

        center_lat, center_lon = 30.75, -97.48
        if row < len(dff):
            if 'location_lat' in dff.columns and 'location_long' in dff.columns:
                center_lat = dff.at[row, 'location_lat']
                center_lon = dff.at[row, 'location_long']

        breed = dff.at[row, 'breed'] if 'breed' in dff.columns else 'Unknown'
        name = dff.at[row, 'name'] if 'name' in dff.columns else 'Unknown'

        return [
            dl.Map(style={'width': '100%', 'height': '500px'},
                   center=[center_lat, center_lon],
                   zoom=10,
                   children=[
                       dl.TileLayer(id='base-layer'),
                       dl.Marker(position=[center_lat, center_lon],
                                 children=[
                                     dl.Tooltip(breed),
                                     dl.Popup([html.H1('Animal Name'),
                                               html.P(name)])
                                 ])
                   ])
        ]

    # Callback for the new Reset All button
    @app.callback(
        Output('rescue-filter', 'value'),
        Output('datatable-id', 'selected_rows'),
        Input('reset-all', 'n_clicks'),
        prevent_initial_call=True
    )
    def reset_all(n_clicks):
        # Return defaults for radio items and selected rows
        return 'Reset', []